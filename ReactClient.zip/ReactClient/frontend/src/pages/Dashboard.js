import React, { Component } from "react";
import "../../node_modules/bootstrap/dist/css/bootstrap.css";
import "./DashboardStyles.scss";
import A from "../assets/images/a.png";
import B from "../assets/images/b.png";
import C from "../assets/images/c.png";
// import BarGarph from "./BarGarph";
import { Link } from "react-router-dom";

class Dashboard extends Component {
  state = {
    users: [],
    ActiveCount: [],
    InActiveCount: [],
  };
  componentDidMount() {
    // let data = JSON.parse(localStorage.getItem("UserList"));
    // const users = data;
    // const ActiveCount = users.filter((user) => user.Status === "active");
    // const InActiveCount = users.filter((user) => user.Status === "inactive");
    // this.setState({ users, ActiveCount, InActiveCount });
  }
  render() {
    return (
      <div className="Info-Card">
        <h4>Dashboard</h4>
        <div className="container">
          <div className="flex-container">
            <div className="flex-child">
            <Link to={{ pathname: "/table" }}  style={{color:"black"}}><h6>Total Users</h6></Link>
            {/* <a routerLinkActive="list-item-active" style="color: black;"routerLink="/tableView">
              <h6>Total Users</h6>
              </a> */}
              <h5>{this.state.users.length}</h5>
              <img
                class="img-fluid"
                style={{ width: "40%", float: "right" }}
                src={A}
                alt="card image"
              />
            </div>
            <div className="flex-child">
              <h6>Active Users</h6>
              <h5>{this.state.ActiveCount.length}</h5>
              <img
                class="img-fluid"
                style={{ width: "40%", float: "right" }}
                src={B}
                alt="card image"
              />
            </div>
            <div className="flex-child">
              <h6>In-Active Users</h6>
              <h5>{this.state.InActiveCount.length}</h5>
              <img
                class="img-fluid"
                style={{ width: "40%", float: "right" }}
                src={C}
                alt="card image"
              />
            </div>
          </div>
        </div>
        <div className="Usergraph-hidden" style={{marginTop:"50px"}}> 
          {/* <BarGarph />{" "} */}
        </div>
      </div>
    );
  }
}

export default Dashboard;