const express = require('express')
const bodyParser = require('body-parser')
const cors = require('cors')
const nodemailer = require('nodemailer');
const xoauth2 = require("xoauth2");

// routers
const routerUser = require('./routes/user')

const app = express()

// add json parser
app.use(bodyParser.json())
app.use(cors('*'))


app.use('/users', routerUser)


app.listen(4000, '0.0.0.0', () => {
  console.log('server started on port 4000')
})