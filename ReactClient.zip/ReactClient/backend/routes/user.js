const express = require('express')
const db = require('../db')
const utils = require('../utils')
const nodemailer = require('nodemailer');

const router = express.Router()

router.post('/signup', (request, response) => {
  const { firstName, lastName, status , email, password} = request.body

  const statement = `insert into users (firstName, lastName, status, email, password) values (
    '${firstName}', '${lastName}', '${status}', '${email}', '${password}')`
  
  db.connnection.query(statement, (error, data) => {
    response.send(utils.createResult(error, data))
  })
})

router.get('/', (request, response) => {

  const statement = `select  firstName, lastName, email, password, status from users`
  
  db.connnection.query(statement, (error, data) => {
    response.send(utils.createResult(error, data))
  })
})

router.post('/login', (request, response) => {
  const { email, password } = request.body

  const statement = `select id, firstName, lastName from users where email = '${email}' and password = '${password}'`
  db.connnection.query(statement, (error, users) => {
    const result = {}

    if (error) {
      result['status'] = 'error'
      result['error'] = error
    } else {
      if (users.length == 0) {
        result['status'] = 'error'
        result['error'] = 'invalid credentials'
      } else {
        const user = users[0]

        result['status'] = 'success'
        result['data'] = user
      }
    }
    response.send(result)
  })
})


router.post('/forgetpassword', (request, response) => {
  const {email} = request.body
  console.log("email-----",email);
  const statement = `select id,  firstName, lastName from users where email = '${email}'`
  //response.send('<h1>Welcome to my backend</h1>')
  db.connnection.query(statement, (error, data) => {
    response.send(utils.createResult(error, data))
    data.forEach( user => {
      console.log(user.id)
 
  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    auth: {
      type: "login", // default
      user: "rupalithange98@gmail.com",
      pass: "Rup@li.."
    }
    // service: 'gmail',
    // auth: {
    //   user: 'rupalithange1998@gmail.com',
    //   pass: 'yourpassword'
    // }
});
  
  var mailOptions = {
    from: 'Rupali Thange <rupalithange98@gmail.com>',
    to: `${email}`,
    subject: 'Password Reset',
    text: `Hello ${user.firstName} ${user.lastName},  
    We received a request to reset your password. 
    Click the link below to set a new password:- http://localhost:8000/resetpassword/${user.id}` 
  }
  
  transporter.sendMail(mailOptions, function(err, res) {
    if (err) {
      console.log(err);
    } else {
      console.log('Email sent');
    }
  })
})
})
})
router.post('/resetpassword/:id', (request, response) => {
  const {id} = request.params
  console.log("id:",id)
  const {password} = request.body
  const statement = `update users set password = ${password} where id = ${id}`

  
  db.connnection.query(statement, (error, data) => {
    response.send(utils.createResult(error, data))
  })
})

module.exports = router
