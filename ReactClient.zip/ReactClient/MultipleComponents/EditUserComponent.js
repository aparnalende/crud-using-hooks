import React, { useState, useEffect } from "react";
import { useHistory,useParams } from "react-router-dom";
import { v1 as uuid } from "uuid";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import UserTableViewComponent from "./UserTableViewComponent";
import { FaRegObjectGroup } from "react-icons/fa";

const EditUserComponent = (props) => {
  const { id } = useParams()

  const [user, setUser] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");

const [name, setName] = useState("")

  let userList = JSON.parse(localStorage.getItem("UserList")) || [];

  useEffect(() => {
   edit(id);
  }, [])



   const edit =(id) => {
    let tempList = JSON.parse(localStorage.getItem("UserList"));

    let editId = tempList.find((uid) => {
      return uid.Id === id;
    });
    console.log("edited data--", editId.Name);
    setUser(editId.Name);
    setEmail(editId.Email);
    setPhone(editId.Phone);
    setStatus(editId.Status);
    setRole(editId.Role);
    setPassword(editId.Password);
    setConfirmPwd(editId.confirmPwd);

    toast.success("User has been edited successfully");
  };
  
  const updateData=(e)=>{
    e.preventDefault();
    let tempList = JSON.parse(localStorage.getItem("UserList"));

    let editId = tempList.find((uid) => {
      if (uid.Id === id){
        return user;
        // userList.push(editId);
      }
    });
    
    let obj = {
      Id:uuid(),
      Name: user,
      Email: email,
      Role: role,
      Phone: phone,
      Status: status,
      Password: password,
      confirmPwd: confirmPwd,
    };
    localStorage.setItem("UserList", JSON.stringify(userList));
    userList.push(obj)

    // toast.success("User has been edited successfully");
    console.log("------",obj)
  
  }


  return (
    <>

      <div className="container">
        <div className="w-50 mx-auto shadow p-5">
          <form  
          onSubmit={updateData}
          >
            <div className="form-group row">
              <label className="col-sm-2 col-form-label">
                Name
                <span aria-hidden="true" style={{ color: "red" }}>
                  *
                </span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control form-control-lg "
                  placeholder="First name"
                  name="name"
                  value={user}
                  onChange={(e) => setUser(e.target.value)}
                />
              </div>
            </div>
            <div className="form-group row">
              <label class="col-sm-2 col-form-label">
                Email
                <span aria-hidden="true" style={{ color: "red" }}>
                  *
                </span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control form-control-lg"
                  placeholder="Email "
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>
            <div className="form-group row">
              <label class="col-sm-2 col-form-label">Phone</label>
              <div className="col-sm-10">
                <input
                  type="number"
                  className="form-control form-control-lg"
                  placeholder="Phone Number"
                  name="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
            </div>

            <div className="form-group row">
              <label class="col-sm-2 col-form-label">Role</label>
              <div className="col-sm-10">
                <select
                  className="form-control"
                  name="select "
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                >
                  <option default>Select Role</option>
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            </div>

            <div className="form-group row">
              <label class="col-sm-2 col-form-label">Status</label>
              <div className="col-sm-10">
                <select
                  className="form-control"
                  name="status "
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option default>Select Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">InActive</option>
                </select>
              </div>
            </div>
            <div className="form-group row">
              <label class="col-sm-2 col-form-label">Password</label>
              <div className="col-sm-10 md-2">
                <input
                  type="password"
                  className="form-control form-control-lg"
                  placeholder="Enter Password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.password)}
                />
              </div>
            </div>
            <div className="form-group row">
              <label class="col-sm-2 col-form-label">Confirm Password</label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control form-control-lg"
                  placeholder="Enter Confirm Password"
                  name="confirmPwd"
                  value={confirmPwd}
                  onChange={(e) => setConfirmPwd(e.target.value)}
                />
              </div>
            </div>
            <button className="btn btn-primary btn-block" onClick={edit}>Update</button>
          </form>
        </div>
      </div>
      <ToastContainer />
    </>
  );
};

export default EditUserComponent;
